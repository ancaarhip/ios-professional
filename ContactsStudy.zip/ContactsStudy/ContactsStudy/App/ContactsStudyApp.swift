//
//  ContactsStudyApp.swift
//  ContactsStudy
//
//  Created by Anca Arhip on 03.11.2022.
//

import SwiftUI

@main
struct ContactsStudyApp: App {
    var body: some Scene {
        WindowGroup {
            HomeView()
        }
    }
}
